#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int ElementType;
//快速排序选主元
int Median3( int A[], int Left, int Right );
//快速排序核心算法
void Qsort( int A[], int Left, int Right );
//建堆的所需操作 /* 将N个元素的数组中以A[p]为根的子堆调整为最大堆 */
void PercDown( ElementType A[], int p, int N );
//堆排序
void HeapSort( ElementType A[], int N );
//二路归并
int* Merge(int start[],int end[],int M);
//寻找最大重叠区间
void GetAnswer(int* time,int M);
void Swap( int *a, int *b )
{
    int t = *a;
    *a = *b;
    *b = t;
}

int Median3( int A[], int Left, int Right )
{
    int Center = (Left+Right) / 2;
    if ( A[Left] > A[Center] )
        Swap( &A[Left], &A[Center] );
    if ( A[Left] > A[Right] )
        Swap( &A[Left], &A[Right] );
    if ( A[Center] > A[Right] )
        Swap( &A[Center], &A[Right] );
    /* 此时A[Left] <= A[Center] <= A[Right] */
    Swap( &A[Center], &A[Right-1] ); /* 将基准Pivot藏到右边*/
    /* 只需要考虑A[Left+1] … A[Right-2] *///缩小规模了，且好表示
    return  A[Right-1];  /* 返回基准Pivot */
}



void Qsort( int A[], int Left, int Right )
{
    if(Right-Left<=1)
    {
        if(A[Left]>A[Right])
        {
            Swap(&A[Left],&A[Right]);
        }
        return;
    }
    /* 核心递归函数 */
    int Pivot, Low, High;
    Pivot = Median3( A, Left, Right ); /* 选基准 */
    Low = Left;
    High = Right-1;
    while (1)   /*将序列中比基准小的移到基准左边，大的移到右边*/
    {
        while ( A[++Low] < Pivot ) ;
        while ( A[--High] > Pivot ) ;
        if ( Low < High ) Swap( &A[Low], &A[High] );
        else break;
    }
    Swap( &A[Low], &A[Right-1] );   /* 将基准换到正确的位置 */
    Qsort( A, Left, Low-1 );    /* 递归解决左边 */
    Qsort( A, Low+1, Right );   /* 递归解决右边 */

}
void QuickSort( int A[], int N )
{
    /* 统一接口 */
    Qsort( A, 0, N-1 );
}



//堆排序：Swap PercDown HeapSort

//建堆的所需操作 /* 将N个元素的数组中以A[p]为根的子堆调整为最大堆 */
void PercDown( ElementType A[], int p, int N )
{
    /* 改编代码4.24的PercDown( MaxHeap H, int p )    */
    /* 将N个元素的数组中以A[p]为根的子堆调整为最大堆 */
    int Parent, Child;
    ElementType X;

    X = A[p]; /* 取出根结点存放的值 */
    for( Parent=p; (Parent*2+1)<N; Parent=Child )
    {
        Child = Parent * 2 + 1;
        if( (Child!=N-1) && (A[Child]<A[Child+1]) )
            Child++;  /* Child指向左右子结点的较大者 */
        if( X >= A[Child] ) break; /* 找到了合适位置 */
        else  /* 下滤X */
            A[Parent] = A[Child];
    }
    A[Parent] = X;
}

//堆排序：O(N*logN)；需要额外O(N)空间，并且复制元素需要时间
void HeapSort( ElementType A[], int N )
{
    /* 堆排序 */
    int i;

    for ( i=N/2-1; i>=0; i-- )/* 建立最大堆 */
        PercDown( A, i, N );

    for ( i=N-1; i>0; i-- )
    {
        /* 删除最大堆顶 */
        Swap( &A[0], &A[i] ); /* 见代码7.1 */
        PercDown( A, 0, i );
    }
}
/*//#5001
int main()
{
    int N;
    scanf("%d",&N);
    int milk[N];
    for(int i=0; i<N; i++)
    {
        scanf("%d",&milk[i]);
    }
    QuickSort(milk, N);

    int medium=(N-1)/2;
    printf("%d",milk[medium]);
    return 0;
}
*/
/*#5002
int main()
{
    int K;
    scanf("%d",&K);
    int N;
    scanf("%d",&N);
    int array[N];
    for(int i=0; i<N; i++)
    {
        scanf("%d",&array[i]);
    }
    QuickSort(array, N);
    for(int i=N-K; i<N; i++)
    {
        printf("%d ",array[i]);
    }
    return 0;
}
*/

int* Merge(int start[],int end[],int M)
{
    int* res=(int*)malloc(sizeof(int)*M*2);
    int cnt0=0,cnt1=0,cnt2=0;
    for(int i=0; i<2*M; i++)
    {
        if(cnt1>=M)
        {
            res[cnt0++]=end[cnt2++];
            continue;
        }
        if(cnt2>=M)
        {
            res[cnt0++]=start[cnt1++];
            continue;
        }
        if(start[cnt1]>end[cnt2])
        {
            res[cnt0++]=end[cnt2++];
        }
        else
        {
            res[cnt0++]=-start[cnt1++];//负数表示标记为start开始
        }

    }
    return res;
}

void Output(int a[],int n)
{
    for(int i=0; i<n; i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");
}
//计算人数最多的起始时间和终止时间
void GetAnswer(int* time,int M)
{
    int answer[500][2]= {0}; //存储可能的数对
    int index=0;
    int Max=-1;
    int count=0;
    for(int i=0; i<2*M; i++)
    {
        if(time[i]<0)//说明是起始时间
        {
            count++;//遇到起始时间就代表进入一个区间，遇到起点加一
            /*可以统计当前进入的区间数量，遇到起点加一，遇到终点减一，
            然后找到过程中令该值最大时加上的起点就可以了。
            又因为在该起点处值是最大的，
            所以之后遇到的点必然是区间的终点，
            也就是走出了这个让进入区间数量最大的区域。这样便确定了最大的重叠区间*/
        }
        if(time[i]>=0)//终止时间
        {
            //找到过程中令该值(count)最大时加上的起点
            if(count>Max)
            {
                Max=count;
                index=0;
                answer[index][0]=-time[i-1];//置负后要还原
                answer[index][1]=time[i];
                index++;
            }
            else if(count==Max)//遇到了多种答案
            {
                answer[index][0]=-time[i-1];
                answer[index][1]=time[i];
                index++;
            }
            count--;//遇到终点减一
        }
    }
    for(int i=0; i<index; i++)
    {
        printf("%d %d",answer[i][0],answer[i][1]);
        if(i!=index-1)
        {
            printf(",");
        }
    }
}
/*5003*/
int main()
{
    int N,M;
    scanf("%d %d",&N,&M);
    int start[M];
    int end[M];
    for(int i=0; i<M; i++)//第i名同学空闲时间的开始时间段与终止时间段
    {
        scanf("%d %d",&start[i],&end[i]);
    }

    QuickSort(start, M);//开始时间段升序排列

    QuickSort(end, M);//终止时间升序排列
    int* a=Merge(start,end,M);
    GetAnswer(a,M);
    return 0;
}
