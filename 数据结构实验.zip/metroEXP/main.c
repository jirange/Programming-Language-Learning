#include <stdio.h>
#include <stdlib.h>
#include <string.h>

# define max_dis 100000
# define NameMaxNum 20
# define FALSE 0
# define TRUE 1
int visited[20];
/*typedef struct
{
    int number;//站点编号
    //char name[NameMaxNum];//站点名称
    char *name;//站点名称
} vextype;*/

typedef char vextype[NameMaxNum];
typedef struct
{
    int N;//N是顶点数，站点数236
    int E;//E是边数，两站相邻是边，29+37+……
    int **matrix;//储存邻接矩阵，权重是时间
    vextype *vertex;//存储节点的信息
} Graph;

Graph createGraph(int n);
int isConnected(Graph g);
void nodeDegree(Graph g, int *node_degree);
double clusteringCoefficient(Graph g);
int Diameter(Graph g);
int Radius(Graph g);
int dijkstra(Graph g, int start, int end, int *path);
void printPath(int d, int *diameter_path, Graph g);

/**
 * 创建一个节点数为n的图
 * @param n 节点个数
 * @return 返回这个图
 */
Graph createGraph(int n)
{
    int i, j;
    Graph g;
    g.N = n;
    g.matrix = (int **) malloc(sizeof(int *) * g.N);
    for (i = 0; i < n; i++)
    {
        g.matrix[i] = (int *) malloc(sizeof(int) * g.N);
    }
    for (i = 0; i < g.N; i++)
    {
        for (j = 0; j < g.N; j++)
        {
            g.matrix[i][j] = max_dis;
        }
    }
    for (i = 0; i < g.N; i++)
    {
        g.matrix[i][i] = 0;
    }
    g.vertex = (vextype *) malloc(sizeof(vextype) * g.N);
    /*for (i = 0; i < g.N; i++)
    {
        g.vertex[i] = (char *) malloc(sizeof(char) * NameMaxNum);
    }*/
    return g;
}

/**
 * 根据距离d和路径数组path输出路径，这样就不需要路径的节点数也能正确输出路径
 * @param d 路径长度
 * @param diameter_path 储存路径的数组
 * @param g 图
 */
void printPath(int d, int *diameter_path, Graph g)
{
    int k = 0;
    int path_length = 0;
    printf("Path: ");
    do
    {
        printf("%s ", g.vertex[diameter_path[k]]);
        path_length += g.matrix[diameter_path[k]][diameter_path[k + 1]];
        k++;
    }
    while (path_length < d);
    printf("%s\n", g.vertex[diameter_path[k]]);
}

/**
 * 判断图是否连通
 * @param g 图
 * @return 连通返回1，否则返回0
 */
void DFS(Graph g, int v)
{
    int w;
    visited[v]=TRUE;
    for(w=0; w<g.N; w++)
    {
        if(g.matrix[v][w]!=max_dis &&g.matrix[v][w]!=0 && !visited[w])
        {
            DFS(g,w);
        }
    }
}
int isConnected(Graph g)
{

    int v = 0;
    for(v=0; v<g.N; v++)
    {
        visited[v] = FALSE;
    }
    DFS(g,0);
    for(int v=0; v<g.N; v++)
    {
        if(!visited[v])
            return 0;
    }
    return 1;
}



/**
 * 计算每个点的度
 * @param g 图
 * @param node_degree 将每个点的度写到这个数组中
 */
void nodeDegree(Graph g, int *node_degree)
{
    int v = 0;
    for(v=0; v<g.N; v++)
    {
        node_degree[v]=0;
        for(int w=0; w<g.N; w++)
        {
            if(g.matrix[v][w]!=max_dis&&g.matrix[v][w]!=0)
            {
                node_degree[v]++;
            }
        }
    }
}
/**
 * 计算图的聚类系数
 * @param g 图
 * @return 返回聚类系数
 */
double clusteringCoefficient(Graph g)
{
    double *vex_clustering_coefficient = (double *)malloc(sizeof(double) * g.N);
    int *degree = (int *)malloc(sizeof(int) * g.N);
    nodeDegree(g, degree);
    int v = 0;
    for(v=0; v<g.N; v++)
    {
        int max_num = 0;
        int exist_num = 0;
        int cnt =0;
        max_num = (degree[v] * (degree[v] - 1))/2;
        if(max_num == 0)
        {
            vex_clustering_coefficient[v] = 0;
            continue;
        }
        int Adjacent[degree[v]];
        for(int w=0; w<g.N; w++)
        {
            if(g.matrix[v][w]!=max_dis && g.matrix[v][w]!=0)
            {
                Adjacent[cnt] = w;
                cnt++;
            }
        }
        for(cnt=0; cnt<degree[v]; cnt++)
        {
            int k = Adjacent[cnt];
            for(int i=cnt; i<degree[v]; i++)
            {
                int w = Adjacent[i];
                if(g.matrix[k][w]!=max_dis && g.matrix[k][w]!=0)
                {
                    exist_num++;
                }
            }
        }
        vex_clustering_coefficient[v] = (double)exist_num/max_num;
    }
    double sum = 0;
    for(v=0; v<g.N; v++)
    {
        sum = sum + vex_clustering_coefficient[v];
    }
    double graph_clustering_coefficient=sum/(g.N);

    free(degree);
    return graph_clustering_coefficient;
}
/**
 * 使用dijkstra算法计算单源最短路径
 * @param g 图
 * @param start 起点
 * @param end 终点
 * @param path 从start到end的路径, [start,...,end]
 * @return 路径长度
 */
void DisplayPath(int *prev,int start,int end,int *path,int n)
{
    int temp[n];
    int cnt = 0;
    for(int i = end; i>=0 ; i=prev[i])
    {
        temp[cnt] = i;
        cnt++;
    }
    int j=0;
    path[0]=start;
    for(j = 1; cnt>0; j++)
    {
        cnt--;
        path[j] = temp[cnt];
    }
}

int dijkstra(Graph g, int start, int end, int *path)
{
    int prev[g.N];
    int dist[g.N];
    int i,j,k;
    int min;
    int tmp;
    int flag[g.N];      // flag[i]=1表示"顶点vs"到"顶点i"的最短路径已成功获取。

    // 初始化
    for (i = 0; i < g.N; i++)
    {
        flag[i] = 0;              // 顶点i的最短路径还没获取到。
        prev[i] = -1;              // 顶点i的前驱顶点为0。
        dist[i] = g.matrix[start][i];// 顶点i的最短路径为"顶点vs"到"顶点i"的权。
    }

    // 对"顶点vs"自身进行初始化
    flag[start] = 1;
    dist[start] = 0;

    // 遍历G.vexnum-1次；每次找出一个顶点的最短路径。
    for (i = 1; i < g.N; i++)
    {
        // 寻找当前最小的路径；
        // 即，在未获取最短路径的顶点中，找到离vs最近的顶点(k)。
        min = max_dis;
        for (j = 0; j < g.N; j++)
        {
            if (flag[j]==0 && dist[j]<min)
            {
                min = dist[j];
                k = j;
            }
        }
        // 标记"顶点k"为已经获取到最短路径
        flag[k] = 1;

        // 修正当前最短路径和前驱顶点
        // 即，当已经"顶点k的最短路径"之后，更新"未获取最短路径的顶点的最短路径和前驱顶点"。
        for (j = 0; j < g.N; j++)
        {
            tmp = (g.matrix[k][j]==max_dis ? max_dis : (min + g.matrix[k][j])); // 防止溢出
            if (flag[j] == 0 && (tmp  < dist[j]) )
            {
                dist[j] = tmp;
                prev[j] = k;
            }
        }
    }
    DisplayPath(prev,start,end,path,g.N);
    return dist[end];
}

void Floyd(Graph g,int distance[][g.N])
{
    for(int i=0; i<g.N; i++)
    {
        for(int j=0; j<g.N; j++)
        {
            distance[i][j] = g.matrix[i][j];
        }
    }
    for(int k=0; k<g.N; k++)
    {
        for(int i=0; i<g.N; i++)
        {
            for(int j=0; j<g.N; j++)
            {
                if(distance[i][k]+distance[k][j]<distance[i][j])
                {
                    distance[i][j]=distance[i][k]+distance[k][j];
                }
            }
        }
    }
}
int max(int *a,int n)
{
    int max=0;
    for(int i=0; i<n; i++)
    {
        if(a[i]>max)
            max=a[i];
    }
    return max;
}
int min(int *a,int n)
{
    int min=a[0];
    for(int i=0; i<n; i++)
    {
        if(a[i]<min)
            min=a[i];
    }
    return min;
}
/**
 * 计算图的直径。提示：Floyd算法
 * @param g 图
 * @return 直径的长度
 */
int Diameter(Graph g)
{
    int Eccentricity[g.N];
    int distance[g.N][g.N];
    Floyd(g,distance);
    for(int i=0; i<g.N; i++)
    {
        Eccentricity[i]=max(distance[i],g.N);

    }

    return max(Eccentricity,g.N);
}


/**
 * 计算图的半径
 * @param g 图
 * @return 半径长度
 */
int Radius(Graph g)
{
    int Eccentricity[g.N];
    int distance[g.N][g.N];
    Floyd(g,distance);
    for(int i=0; i<g.N; i++)
    {
        Eccentricity[i]=max(distance[i],g.N);
    }
    return min(Eccentricity,g.N);
}


int main()
{
    int node_num;//顶点数//总站点数:236
    //int edge_num;//边数
    int subway_lines_num;//线路总数：10
    //int single_station_num;//单个线路站点数

    //int ca = 1;

    scanf("%d %d\n", &node_num, &subway_lines_num);

    //int count=0;
    int line[subway_lines_num];//第i个线路的站点数
    Graph g = createGraph(node_num);
    int start_idx, end_idx, weight;
    for(int i=0; i<subway_lines_num; i++)
    {
        scanf("%d\n", &line[i]);
        for (int j = 0; j < line[i]; j++)
        {
            scanf("%d %d\n", &end_idx,&weight);
            if(j==0)
            {
                g.matrix[end_idx][end_idx] = weight;
            }
            else
            {
                g.matrix[start_idx][end_idx] = weight;
                g.matrix[end_idx][start_idx] = weight;
            }
            start_idx=end_idx;

        }
    }

    scanf("%d\n", &node_num);

    int number;
    //char name[NameMaxNum];
    for(int i=0; i<node_num; i++)
    {
        scanf("%d ",&number);
        scanf("%s\n",g.vertex[number]);

    }



    /*该线路图是连通的吗？*/
    if(isConnected(g))
        printf("是连通图\n");
    else printf("不是连通图\n");

    //printf("connected: %d\n", isConnected(g));
    /*线路图中换乘线路最多·的站点是哪个？共有几条线路通过？*/
    int *degree = (int *)malloc(sizeof(int) * g.N);
    nodeDegree(g, degree);
    /*printf("degree distribution:\n");
    for(int i=0; i<g.N; i++)
    {
        printf("node%s:%d,", g.vertex[i], degree[i]);
    }*/
    int max_degree=0;
    int max_degree_point;
    for(int i=0; i<g.N; i++)
    {
        if(degree[i]>max_degree)
        {
            max_degree=degree[i];
            max_degree_point=i;
        }

    }
    printf("%s %d条线路\n", g.vertex[max_degree_point], max_degree);
    free(degree);

    /*double c = clusteringCoefficient(g);
    printf("clustering coefficient:%f\n", c);*/

    if(isConnected(g))
    {
        /*该线路图的直径和半径是多少？*/
        int d = Diameter(g);
        printf("直径%d ", d);

        int r = Radius(g);
        printf("半径%d\n", r);
        /*从x站到y站最少需要多少时间？请打印推荐路径上的站点名称*/
        int x,y;
        scanf("%d %d\n", &x, &y);
        int *short_path = (int *)malloc(sizeof(int) * g.N);
        int dis = dijkstra(g, x, y, short_path);
        printf("%s到%s%d分钟 ", g.vertex[x],g.vertex[y],dis);
        printPath(dis, short_path, g);
        free(short_path);


    }

    return 0;
}


